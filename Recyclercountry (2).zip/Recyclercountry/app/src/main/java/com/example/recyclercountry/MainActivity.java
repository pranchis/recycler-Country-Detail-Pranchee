package com.example.recyclercountry;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView textView, textView2, textView3, textView4, textView5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Countries");

        textView = findViewById(R.id.btn_Nepal);
        textView2 = findViewById(R.id.btn_india);
        textView3 = findViewById(R.id.btn_japan);
        textView4 = findViewById(R.id.btn_srilanka);
        textView5 = findViewById(R.id.btn_china);


        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Nepal.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "You Clicked Nepal", Toast.LENGTH_SHORT).show();
            }
        });

        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, India.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "You Clicked India", Toast.LENGTH_SHORT).show();

            }
        });

        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Japan.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "You Clicked Japan", Toast.LENGTH_SHORT).show();

            }
        });

        textView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Srilanka.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "You Clicked Srilanka", Toast.LENGTH_SHORT).show();

            }
        });

        textView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, China.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "You Clicked Dubai//china", Toast.LENGTH_SHORT).show();

            }
        });
    }
}